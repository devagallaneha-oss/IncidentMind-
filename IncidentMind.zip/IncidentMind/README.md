# IncidentMind — AI Production Incident Memory Agent

A React + Express application for analysing production incidents, learning from previous incidents, and presenting practical recommendations in a dashboard.

## Run in VS Code (Windows)

**Requirements:** Node.js 20.19+ or 22.12+ and VS Code.

1. Extract the `IncidentMind` folder.
2. Open that folder in VS Code (`File → Open Folder`).
3. Open a terminal and run the backend:

   ```bash
   cd backend
   npm install
   copy .env.example .env
   npm run dev
   ```

4. Open a **second** VS Code terminal and run the frontend:

   ```bash
   cd frontend
   npm install
   npm run dev
   ```

5. Open the local address printed by Vite (normally `http://localhost:5173`). Keep both terminals running.

## AI and memory connections (optional)

The project runs in **local demo mode** without API credentials. For live AI recommendations and persistent Hindsight memory, open `backend/.env` and add your own credentials:

- `GROQ_API_KEY` — Groq API key
- `HINDSIGHT_BASE_URL` — your Hindsight service base URL
- `HINDSIGHT_API_KEY` — your Hindsight API key

Restart the backend after editing `.env`. Never share or upload your `.env` file publicly.

## Features

- Lavender IncidentMind dashboard with responsive layout and light/dark toggle
- Incident analysis form and recommendation panel
- Past incident history with search
- Analytics overview
- Local fallback analysis when external AI services are not configured or temporarily unavailable
- Optional Groq + Hindsight integration

## API

- `GET /` — backend health
- `GET /incidents` — incident history
- `POST /incidents` — analyse and save an incident (`{ "problem": "..." }`)
