import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { HindsightClient } from '@vectorize-io/hindsight-client';
import Groq from 'groq-sdk';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
const PORT = Number(process.env.PORT || 5000);
const BANK_ID = process.env.HINDSIGHT_BANK_ID || 'incidentmind';
const hasHindsight = Boolean(process.env.HINDSIGHT_BASE_URL && process.env.HINDSIGHT_API_KEY);
const hasGroq = Boolean(process.env.GROQ_API_KEY);
const hindsight = hasHindsight ? new HindsightClient({ baseUrl: process.env.HINDSIGHT_BASE_URL, apiKey: process.env.HINDSIGHT_API_KEY }) : null;
const groq = hasGroq ? new Groq({ apiKey: process.env.GROQ_API_KEY }) : null;

let incidentHistory = [
  { id: 1, date: 'Oct 12, 2026', title: 'Payment API 503 Errors', rootCause: 'DB Pool Exhausted', resolution: 'Scaled DB + Optimized Queries', outcome: 'Resolved in 15 mins, no data loss.' },
  { id: 2, date: 'Aug 28, 2026', title: 'High Latency in Payments', rootCause: 'Traffic Spike', resolution: 'Added Auto Scaling', outcome: 'Latency returned to normal.' },
  { id: 3, date: 'Jul 15, 2026', title: 'Payment Failures', rootCause: 'Connection Pool Limit', resolution: 'Increased Pool Size', outcome: 'Payment processing restored.' },
];

function localAnalysis(problem) {
  const lower = problem.toLowerCase();
  let rootCause = 'Possible service resource exhaustion, configuration issue, or dependency failure.';
  let action = 'Check application logs, service health, and dependent services. Apply the smallest safe fix and monitor recovery.';
  let relevance = 'Past incidents help identify recurring failure patterns and avoid repeating unsuccessful fixes.';
  let checks = 'Monitor error rate, latency, CPU/memory, and the relevant service health metrics.';
  if (lower.includes('503') || lower.includes('payment') || lower.includes('database') || lower.includes('db')) {
    rootCause = 'Possible database connection pool exhaustion during a sudden traffic spike.';
    action = 'Inspect active database connections and pool limits. Confirm database capacity, then scale database resources or tune queries if required.';
    relevance = 'Previous payment incidents were linked to connection-pool limits; restarting services alone did not provide a lasting fix.';
    checks = 'Verify payment success rate, HTTP 5xx count, database pool usage, and query latency after the change.';
  } else if (lower.includes('latency') || lower.includes('slow')) {
    rootCause = 'High request volume or a slow downstream dependency may be increasing response time.';
    action = 'Check traces and slow queries, identify the slow dependency, and scale the constrained service if capacity is the bottleneck.';
    relevance = 'Earlier high-latency incidents improved after capacity was scaled and the bottleneck was isolated.';
    checks = 'Track p95/p99 latency, request volume, queue depth, and downstream response times.';
  }
  return { rootCause, action, relevance, checks, recommendation: action };
}

app.get('/', (_req, res) => res.json({ message: 'IncidentMind backend is running', mode: hasGroq || hasHindsight ? 'connected' : 'demo' }));
app.get('/incidents', (_req, res) => res.json({ success: true, incidents: incidentHistory }));

app.post('/incidents', async (req, res) => {
  const problem = typeof req.body?.problem === 'string' ? req.body.problem.trim() : '';
  if (!problem) return res.status(400).json({ success: false, error: 'Please provide an incident description.' });
  if (problem.length > 4000) return res.status(400).json({ success: false, error: 'Incident description must be under 4,000 characters.' });

  const analysis = localAnalysis(problem);
  let memories = [];
  let memoryConnected = false;
  if (hindsight) {
    try {
      memories = await hindsight.recall(BANK_ID, problem);
      memoryConnected = true;
    } catch (error) { console.warn('Hindsight recall unavailable:', error.message); }
  }

  let recommendation = analysis.recommendation;
  let aiConnected = false;
  if (groq) {
    try {
      const completion = await groq.chat.completions.create({
        model: process.env.GROQ_MODEL || 'openai/gpt-oss-20b',
        messages: [
          { role: 'system', content: 'You are IncidentMind, a careful production incident response assistant. Use the supplied past incident memories when relevant. Never claim a fix was applied. Give concise, safe operational advice.' },
          { role: 'user', content: `Current incident:\n${problem}\n\nPast incident memories:\n${JSON.stringify(memories).slice(0, 12000)}\n\nReturn these four labeled lines: Likely cause: ...\nRecommended action: ...\nWhy relevant: ...\nWhat to check: ...` }
        ],
        temperature: 0.2,
      });
      const text = completion.choices?.[0]?.message?.content || '';
      if (text) {
        recommendation = text;
        const get = (label, fallback) => text.match(new RegExp(`${label}\\s*[:\\-]\\s*([^\\n]+)`, 'i'))?.[1]?.trim() || fallback;
        analysis.rootCause = get('Likely cause', analysis.rootCause);
        analysis.action = get('Recommended action', analysis.action);
        analysis.relevance = get('Why relevant', analysis.relevance);
        analysis.checks = get('What to check', analysis.checks);
        aiConnected = true;
      }
    } catch (error) { console.warn('Groq unavailable; using local analysis:', error.message); }
  }

  if (hindsight) {
    try {
      await hindsight.retain(BANK_ID, `Incident: ${problem}\nLikely cause: ${analysis.rootCause}\nRecommended action: ${analysis.action}`);
    } catch (error) { console.warn('Hindsight retain unavailable:', error.message); }
  }

  const newIncident = {
    id: Date.now(),
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
    title: problem.length > 48 ? `${problem.slice(0, 48)}…` : problem,
    rootCause: analysis.rootCause,
    resolution: analysis.action,
    outcome: 'Recommendation generated; verify the system after applying the fix.'
  };
  incidentHistory = [newIncident, ...incidentHistory].slice(0, 50);
  return res.json({ success: true, problem, analysis, recommendation, memories, incidents: incidentHistory, mode: aiConnected && memoryConnected ? 'Groq AI + Hindsight memory' : aiConnected ? 'Groq AI' : memoryConnected ? 'Local analysis + Hindsight memory' : 'Local demo analysis' });
});

app.listen(PORT, () => console.log(`IncidentMind backend running at http://localhost:${PORT}`));
